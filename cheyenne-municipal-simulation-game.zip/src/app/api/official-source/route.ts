import { NextRequest, NextResponse } from "next/server";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { ORDINANCES } from "@/lib/civic-data";

const fileNames: Record<string, string> = { agenda: "2026-01-26-agenda.pdf", minutes: "2026-01-26-minutes.pdf", ...Object.fromEntries(ORDINANCES.map((o) => [o.id, `${o.id}.pdf`])) };
export async function GET(request: NextRequest) {
  const id = request.nextUrl.searchParams.get("id") || "";
  const name = fileNames[id];
  if (!name) return NextResponse.json({ error: "Unknown official source." }, { status: 404 });
  try {
    const bytes = await readFile(path.join(process.cwd(), "public/sources", name));
    const isPdf = bytes.subarray(0,5).toString() === "%PDF-";
    const headers: Record<string,string> = { "Content-Type": isPdf ? "application/pdf" : "text/html; charset=utf-8", "Cache-Control": "public, max-age=86400", "X-Content-Type-Options":"nosniff" };
    if (isPdf) headers["Content-Disposition"] = `inline; filename="${name}"`;
    else headers["Content-Security-Policy"] = "sandbox allow-popups allow-popups-to-escape-sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src https: data:; base-uri 'none'; form-action 'none'; frame-ancestors 'self'";
    return new NextResponse(new Uint8Array(bytes), { headers });
  } catch {
    return NextResponse.json({ error: "The local document is unavailable. Please use the original official source link." }, { status: 503 });
  }
}
