import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { civicBookmarks, civicProgress } from "@/db/schema";
import { ORDINANCES, REPOSITORIES } from "@/lib/civic-data";

export const dynamic = "force-dynamic";
function visitor(request: NextRequest) {
  const value = request.cookies.get("civic_visitor")?.value;
  return value && /^[0-9a-f-]{36}$/i.test(value) ? value : randomUUID();
}
function respond(data: unknown, id: string, status = 200) {
  const response = NextResponse.json(data, { status, headers: { "Cache-Control": "private, no-store" } });
  response.cookies.set("civic_visitor", id, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" && process.env.COOKIE_SECURE === "true", path: "/", maxAge: 60 * 60 * 24 * 365 });
  return response;
}
export async function GET(request: NextRequest) {
  const id = visitor(request);
  try {
    const [progress, bookmarks] = await Promise.all([
      db.select().from(civicProgress).where(eq(civicProgress.visitorId, id)),
      db.select().from(civicBookmarks).where(eq(civicBookmarks.visitorId, id)),
    ]);
    return respond({ progress, bookmarks }, id);
  } catch {
    return respond({ error: "Your notebook is temporarily unavailable. Please try again." }, id, 503);
  }
}
export async function POST(request: NextRequest) {
  const id = visitor(request);
  try {
    const body = await request.json();
    if (body.action === "progress") {
      if (!ORDINANCES.some((o) => o.id === body.ordinanceId) || !["read", "watch", "impact", "reflect"].includes(body.stage)) return respond({ error: "Choose a valid ordinance and reading stage." }, id, 400);
      if (body.position != null && !["support", "questions", "oppose"].includes(body.position)) return respond({ error: "Invalid reflection position." }, id, 400);
      if (typeof body.reflection !== "string" || body.reflection.length > 5000) return respond({ error: "Reflections must be 5,000 characters or fewer." }, id, 400);
      const values = { visitorId: id, ordinanceId: body.ordinanceId as string, stage: body.stage as string, position: (body.position || null) as string | null, reflection: body.reflection as string, updatedAt: new Date() };
      const [saved] = await db.insert(civicProgress).values(values).onConflictDoUpdate({ target: [civicProgress.visitorId, civicProgress.ordinanceId], set: { stage: values.stage, position: values.position, reflection: values.reflection, updatedAt: values.updatedAt } }).returning();
      return respond({ progress: saved }, id);
    }
    if (body.action === "bookmark") {
      if (!REPOSITORIES.some((r) => r.id === body.repo) || typeof body.path !== "string" || !body.path || body.path.length > 1500) return respond({ error: "Invalid source." }, id, 400);
      const condition = and(eq(civicBookmarks.visitorId, id), eq(civicBookmarks.repo, body.repo), eq(civicBookmarks.path, body.path));
      const [existing] = await db.select().from(civicBookmarks).where(condition);
      if (existing) {
        await db.delete(civicBookmarks).where(condition);
        return respond({ removed: true, path: body.path, repo: body.repo }, id);
      }
      const [bookmark] = await db.insert(civicBookmarks).values({ visitorId: id, repo: body.repo, path: body.path }).onConflictDoNothing().returning();
      return respond({ bookmark }, id);
    }
    return respond({ error: "Unknown notebook action." }, id, 400);
  } catch {
    return respond({ error: "Your changes could not be saved. Please try again." }, id, 503);
  }
}
