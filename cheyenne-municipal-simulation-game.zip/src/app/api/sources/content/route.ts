import { NextRequest, NextResponse } from "next/server";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { getArchive } from "@/lib/archive";
import { ARCHIVE_REPO, TRANSCRIPT_REPO, MEETING, rawUrl } from "@/lib/civic-data";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const repo = request.nextUrl.searchParams.get("repo") || ARCHIVE_REPO;
  const filePath = request.nextUrl.searchParams.get("path") || "";
  try {
    const archive = await getArchive(repo);
    const entry = archive.files.find((file) => file.path === filePath);
    if (!entry) return NextResponse.json({ error: "Source not found in the repository index." }, { status: 404 });
    if (entry.size > 35000000) return NextResponse.json({ error: "This source is too large for inline preview. Open the original on GitHub or download it directly." }, { status: 413 });
    let bytes: ArrayBuffer;
    if (repo === TRANSCRIPT_REPO && filePath === MEETING.transcriptPath) {
      const buffer = await readFile(path.join(process.cwd(), "src/data/jan-26-transcript.md"));
      bytes = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength) as ArrayBuffer;
    } else if (repo === ARCHIVE_REPO && filePath === `${MEETING.archiveFolder}/Agenda.pdf`) {
      const buffer = await readFile(path.join(process.cwd(), "public/sources/2026-01-26-agenda.pdf"));
      bytes = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength) as ArrayBuffer;
    } else {
      const response = await fetch(rawUrl(repo, filePath), { signal: AbortSignal.timeout(20000), next: { revalidate: 3600 } });
      if (!response.ok) throw new Error("Source unavailable");
      bytes = await response.arrayBuffer();
    }
    const head = new TextDecoder().decode(bytes.slice(0,512));
    const isPdf = head.startsWith("%PDF-");
    const isArchivedHtml = /\.(pdf|bin)$/i.test(filePath) && !isPdf && /<(script|html|!doctype|style|title)\b/i.test(head);
    const isText = /\.(md|txt|json|csv|sh|yml|yaml|js|ts|html|css)$/i.test(filePath);
    const headers: Record<string,string> = { "Content-Type": isPdf ? "application/pdf" : isArchivedHtml ? "text/html; charset=utf-8" : isText ? "text/plain; charset=utf-8" : "application/octet-stream", "Cache-Control": "public, max-age=3600", "X-Content-Type-Options": "nosniff" };
    if (request.nextUrl.searchParams.get("download") === "1" || !isArchivedHtml) headers["Content-Disposition"] = `${request.nextUrl.searchParams.get("download") === "1" ? "attachment" : "inline"}; filename*=UTF-8''${encodeURIComponent(filePath.split("/").pop() || "source")}`;
    if (isArchivedHtml) headers["Content-Security-Policy"] = "sandbox allow-popups allow-popups-to-escape-sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src https: data:; base-uri 'none'; form-action 'none'; frame-ancestors 'self'";
    return new NextResponse(bytes, { headers });
  } catch {
    return NextResponse.json({ error: "We couldn’t load this source. The original GitHub file is still available through the source link." }, { status: 502 });
  }
}
