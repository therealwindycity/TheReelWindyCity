import { NextRequest, NextResponse } from "next/server";
import { getArchive } from "@/lib/archive";
import { ARCHIVE_REPO } from "@/lib/civic-data";

export async function GET(request: NextRequest) {
  const repo = request.nextUrl.searchParams.get("repo") || ARCHIVE_REPO;
  try {
    const data = await getArchive(repo);
    return NextResponse.json(data, { headers: { "Cache-Control": "public, max-age=300" } });
  } catch {
    return NextResponse.json({ error: "The repository could not be reached. Please retry or open the original archive on GitHub." }, { status: 502 });
  }
}
