import { pgTable, text, timestamp, uuid, uniqueIndex } from "drizzle-orm/pg-core";

export const civicProgress = pgTable("civic_progress", {
  id: uuid("id").defaultRandom().primaryKey(),
  visitorId: text("visitor_id").notNull(),
  ordinanceId: text("ordinance_id").notNull(),
  stage: text("stage").notNull().default("read"),
  position: text("position"),
  reflection: text("reflection").notNull().default(""),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => [uniqueIndex("civic_progress_visitor_ordinance").on(table.visitorId, table.ordinanceId)]);

export const civicBookmarks = pgTable("civic_bookmarks", {
  id: uuid("id").defaultRandom().primaryKey(),
  visitorId: text("visitor_id").notNull(),
  repo: text("repo").notNull(),
  path: text("path").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [uniqueIndex("civic_bookmarks_visitor_source").on(table.visitorId, table.repo, table.path)]);
