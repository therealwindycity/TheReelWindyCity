import "server-only";
import { readFile } from "node:fs/promises";
import path from "node:path";
import archiveSnapshot from "@/data/archive-tree.json";
import transcriptSnapshot from "@/data/transcript-tree.json";
import { ARCHIVE_OWNER, ARCHIVE_REPO, TRANSCRIPT_REPO, REPOSITORIES, type SourceFile } from "./civic-data";

type TreeEntry = { path: string; type: string; sha: string; size?: number };
type GithubTree = { tree?: TreeEntry[]; truncated?: boolean; sha?: string; message?: string };
const cache = new Map<string, { at: number; data: { files: SourceFile[]; snapshot: boolean; sha: string } }>();

export function toSourceFiles(tree: TreeEntry[], repo: string): SourceFile[] {
  return tree.filter((entry) => entry.type === "blob").map((entry) => ({ path: entry.path, sha: entry.sha, size: entry.size || 0, repo,
    type: entry.path.toLowerCase().endsWith(".pdf") ? "PDF" as const : entry.path.includes("transcripts/") && entry.path.endsWith(".md") ? "Transcript" as const : "Source" as const,
  })).sort((a, b) => a.path.localeCompare(b.path));
}
export function getSnapshot(repo = ARCHIVE_REPO) {
  const data = repo === TRANSCRIPT_REPO ? transcriptSnapshot : archiveSnapshot;
  return { files: toSourceFiles(data.tree, repo), snapshot: true, sha: data.sha };
}
export async function getArchive(repo: string) {
  if (!REPOSITORIES.some((r) => r.id === repo)) throw new Error("Unknown repository");
  const cached = cache.get(repo);
  if (cached && Date.now() - cached.at < 3600000) return cached.data;
  try {
    const headers: Record<string, string> = { Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28" };
    if (process.env.GITHUB_TOKEN) headers.Authorization = `Bearer ${process.env.GITHUB_TOKEN}`;
    const res = await fetch(`https://api.github.com/repos/${ARCHIVE_OWNER}/${repo}/git/trees/main?recursive=1`, { headers, signal: AbortSignal.timeout(8000), next: { revalidate: 3600 } });
    if (!res.ok) throw new Error(`GitHub returned ${res.status}`);
    const data: GithubTree = await res.json();
    if (!data.tree || data.truncated) throw new Error("Repository index is incomplete");
    const result = { files: toSourceFiles(data.tree, repo), snapshot: false, sha: data.sha || "" };
    cache.set(repo, { at: Date.now(), data: result });
    return result;
  } catch (error) {
    let result;
    if (repo === ARCHIVE_REPO || repo === TRANSCRIPT_REPO) result = getSnapshot(repo);
    else {
      const data: GithubTree = JSON.parse(await readFile(path.join(process.cwd(), "src/data/repos", `${repo}.json`), "utf8"));
      if (!data.tree || data.truncated) throw error;
      result = { files: toSourceFiles(data.tree, repo), snapshot: true, sha: data.sha || "" };
    }
    cache.set(repo, { at: Date.now(), data: result });
    return result;
  }
}
