#!/bin/bash
# Mirrors .github/workflows/ci.yml step order; continues past failures so we see every red step.
cd /home/user/audit/reel
export NEXT_PUBLIC_BASE_PATH=/TheReelWindyCity CI=true
L=/home/user/audit/ci-logs; mkdir -p $L; : > $L/summary.txt
step(){ name="$1"; shift; s=$(date +%s); "$@" > "$L/$name.log" 2>&1; rc=$?; echo "$name rc=$rc $(( $(date +%s)-s ))s" >> $L/summary.txt; }
step lint npm run lint
step typecheck npm run typecheck
for t in legal-cross-reference legal-audit legal-evidence legal-support ecosystem wyoming-watch places sync pulse filenames scanner-archive-links transcripts calendar; do step "test-$t" npm run test:$t; done
step build npm run build
step test-seo npm run test:seo
echo DONE >> $L/summary.txt
