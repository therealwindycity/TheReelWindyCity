// Evidence probe: what do the browser accessibility tree and rendered text actually expose?
import { chromium } from "@playwright/test";
const BASE = process.env.BASE_URL || "http://127.0.0.1:3000/TheReelWindyCity";
const pages = (process.env.PAGES || "/,/meetings/,/meetings/finance-committee-2026-10-06/,/meetings/city-council-2026-01-26/,/transcripts/,/hub/,/explore/,/workspace/").split(",");
const GLUE = [/Source library\d/, /civic journey\d/, /Official agenda[a-z]+\./, /Granicus meeting page[a-z]+\./, /20\d\d(City|Finance|Public)/, /All meetingsLive/, /CheyenneIndependent/, /CouncilSpecial/, /[a-z]\d+ files?\b/];
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
let total = 0;
for (const p of pages) {
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e).slice(0, 160)));
  const resp = await page.goto(BASE + p, { waitUntil: "networkidle", timeout: 60000 }).catch((e) => ({ status: () => "ERR " + e.message.slice(0, 80) }));
  await page.waitForTimeout(600);
  const snap = await page.locator("body").ariaSnapshot().catch(() => "");
  const info = await page.evaluate(() => {
    const out = { lang: document.documentElement.lang, skip: [], unlabeled: [], inner: document.body.innerText, navs: [], mainCount: document.querySelectorAll("main").length, h1: document.querySelectorAll("h1").length };
    for (const a of document.querySelectorAll('a[href^="#"]')) if (/skip/i.test(a.textContent)) out.skip.push({ href: a.getAttribute("href"), targetExists: !!document.getElementById(a.getAttribute("href").slice(1)), focusable: (() => { const t = document.getElementById(a.getAttribute("href").slice(1)); return t ? (t.tabIndex >= -1 && t.hasAttribute("tabindex")) || /^(A|BUTTON|INPUT)$/.test(t.tagName) : false; })() });
    for (const el of document.querySelectorAll("input:not([type=hidden]),select,textarea")) {
      const id = el.id, lab = (id && document.querySelector(`label[for="${CSS.escape(id)}"]`)) || el.closest("label");
      if (!lab && !el.getAttribute("aria-label") && !el.getAttribute("aria-labelledby") && !el.getAttribute("title")) out.unlabeled.push(el.outerHTML.slice(0, 140));
    }
    for (const n of document.querySelectorAll("nav")) out.navs.push((n.getAttribute("aria-label") || n.getAttribute("aria-labelledby") || "(unnamed)") + (n.querySelector("ul,ol") ? " [list]" : " [no list]"));
    return out;
  });
  const hitsAria = GLUE.flatMap((re) => (snap.match(new RegExp(".{0,25}" + re.source + ".{0,25}", "g")) || []).slice(0, 2));
  const hitsText = GLUE.flatMap((re) => (info.inner.match(new RegExp(".{0,25}" + re.source + ".{0,25}", "g")) || []).slice(0, 2));
  total += hitsAria.length + info.unlabeled.length + info.skip.filter((s) => !s.targetExists).length;
  console.log(`\n=== ${p}  status=${resp.status()} lang=${info.lang} mains=${info.mainCount} h1=${info.h1} jsErrors=${errors.length}`);
  console.log("  skip links:", JSON.stringify(info.skip));
  console.log("  navs:", info.navs.join(" | "));
  console.log("  unlabeled controls:", info.unlabeled.length, info.unlabeled.slice(0, 4));
  console.log("  glued in ACCESSIBILITY TREE:", hitsAria.length, hitsAria.slice(0, 8));
  console.log("  glued in rendered innerText:", hitsText.length, hitsText.slice(0, 6));
  if (errors.length) console.log("  js errors:", errors.slice(0, 3));
  await page.close();
}
await browser.close();
console.log("\nTOTAL_DEFECTS=" + total);
